//
//  ViewController.h
//  pickviewDelegate
//
//  Created by 刘凯 on 15/7/24.
//  Copyright (c) 2015年 刘凯. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "pickViewController.h"

@interface ViewController : UIViewController<pickViewDelegate>

@property (nonatomic, weak) IBOutlet UILabel *showTextLb;


@end

