//
//  ViewController.m
//  pickviewDelegate
//
//  Created by 刘凯 on 15/7/24.
//  Copyright (c) 2015年 刘凯. All rights reserved.
//

#import "ViewController.h"
#import "pickViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)clickBtn:(id)sender{
    pickViewController *pick = [[pickViewController alloc] initWithNibName:@"pickViewController" bundle:nil];
    pick.delegate = self;
    pick.modalPresentationStyle = UIModalPresentationCustom;
    [self presentViewController:pick animated:YES completion:nil];
}
- (void)getTextStr:(NSString *)text{
    _showTextLb.text = text;
}

@end
