//
//  ViewController.m
//  coredata
//
//  Created by 孙波 on 16-11-07.
//  Copyright (c) 2015年 hn3l. All rights reserved.
//
/*
 *  使用方法：
 *  1.创建 数据模型文件 DataModel.xcdatamodeld
 *  2.添加实体 Student 在实体中添加字段 studentId name sex age
 *  3.根据实体生成 Student 类 Editor -> Create NSManagedObject Subclass -> next -> next
 *  4.根据项目实际需要 使用 Student 类里面的方法
 */
#import "ViewController.h"
#import "Student.h"//导入数据模型头文件
@interface ViewController ()
{
    NSArray *dataArr;
}
- (IBAction)addData:(id)sender;
- (IBAction)selectWithId:(id)sender;
- (IBAction)selectAll:(id)sender;
- (IBAction)deleteWithId:(id)sender;
- (IBAction)deleteAll:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    dataArr = @[
                  @{@"studentId":@"1",@"name":@"xiaohong",@"age":@"18",@"sex":@"男"},
                  @{@"studentId":@"2",@"name":@"gang",@"age":@"19",@"sex":@"女"},
                  @{@"studentId":@"3",@"name":@"nihao",@"age":@"16",@"sex":@"男"}];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

- (IBAction)addData:(id)sender
{
    [Student addOrUpdateDataWithDic:dataArr[0]];//添加或更新数据
    [Student addOrUpdateDataWithDic:dataArr[1]];
    [Student addOrUpdateDataWithDic:dataArr[2]];
}

- (IBAction)selectWithId:(id)sender
{
    Student *student = [Student selectDataWithStudentID:1];
    
    NSLog(@"根据id查询数据：\n name = %@ studentId = %@",student.name,student.studentId);
}

- (IBAction)selectAll:(id)sender
{
    NSArray *selectList = [Student selectAllData];
    for (Student *student in selectList) {
        NSLog(@"查询所有数据：\n name = %@ studentId = %@",student.name,student.studentId);
    }
}

- (IBAction)deleteWithId:(id)sender
{
    [Student deleteId:@"1"];//删除studentId 为 1 的一条数据
}

- (IBAction)deleteAll:(id)sender
{
    [Student deleteAllData];//删除所有数据
}
@end
