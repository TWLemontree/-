//
//  Student.h
//  coredata
//
//  Created by 孙波 on 16-11-07.
//  Copyright (c) 2015年 hn3l. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "ModelDataManager.h"//导入数据模型管理方法

@interface Student : NSManagedObject

@property (nonatomic, retain) NSString * studentId;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * sex;
@property (nonatomic, retain) NSString * age;


/**
 *  添加或者更新表内容
 *
 *  @param jsonArray 添加更新的数组
 */
+ (void) addOrUpdateDataWithDic:(NSDictionary *)studentDic;

/**
 *  插入数据
 *
 *  @param studentDic 需要插入的数据
 */
+(void)insertDataWithData:(NSDictionary *)studentDic;

/**
 *  更新所有的字段
 *
 *  @param studentDic 需要的信息
 */
+ (void)updateDataWithData:(NSDictionary *)studentDic;

/**
 *  根据id查询信息
 *
 *  @param ID id
 *
 *  @return 查询结果
 */
+(Student *)selectDataWithStudentID:(NSInteger)studentId;

/**
 *  查询所有的信息
 *
 *  @return 所有信息数组
 */
+(NSArray *)selectAllData;

/**
 *  删除指定id
 *
 *  @param id_ id_
 */
+ (void)deleteId:(NSString *)studentId;

/**
 *  删除所有数据
 *
 */
+ (void)deleteAllData;

@end
