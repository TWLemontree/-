//
//  Student.m
//  coredata
//
//  Created by 孙波 on 16-11-07.
//  Copyright (c) 2015年 hn3l. All rights reserved.
//

#import "Student.h"


@implementation Student

@dynamic studentId;
@dynamic name;
@dynamic sex;
@dynamic age;


/**
 *  添加或者更新表内容
 *
 *  @param jsonArray 添加更新的数组
 */
+ (void) addOrUpdateDataWithDic:(NSDictionary *)studentDic
{
    //首先根据将要添加的 studentId 查询 如果数据库中有这条数据就更新数据，否则就插入插入
    if ([Student selectDataWithStudentID:[[studentDic objectForKey:@"studentId"] integerValue]])
    {
        [Student updateDataWithData:studentDic];//更新数据
    }
    else
    {
        [Student insertDataWithData:studentDic];//插入数据
    }
}

/**
 *  插入数据
 *
 *  @param studentDic 需要插入的数据
 */
+(void)insertDataWithData:(NSDictionary *)studentDic
{
    NSManagedObjectContext *managedObjectContext = [[ModelDataManager sharedManager] managedObjectContext];
    
    //把数据添加到数据库中
    Student *student = [NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:managedObjectContext];
    student.studentId = [studentDic objectForKey:@"studentId"];
    student.name = [studentDic objectForKey:@"name"];
    student.sex = [studentDic objectForKey:@"sex"];
    student.age = [studentDic objectForKey:@"age"];
    
    NSLog(@"存入数据库id------>%@",student);
    [[ModelDataManager sharedManager] saveContextUpdates];
    
}

/**
 *  更新所有的字段
 *
 *  @param studentDic 需要的信息
 */
+ (void)updateDataWithData:(NSDictionary *)studentDic
{
    NSManagedObjectContext *context = [[ModelDataManager sharedManager] managedObjectContext];
    
    //根据studentId 在 Student 表中查询出对应信息
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(studentId = %@)",[studentDic objectForKey:@"studentId"]];
    [fetchRequest setPredicate:predicate];
    NSError *error;
    NSArray *fetchedObjectsArray = [context executeFetchRequest:fetchRequest error:&error];
    //把查询到的信息更新为现有的数据
    for (Student *student in fetchedObjectsArray) {
        student.studentId = [studentDic objectForKey:@"studentId"];
        student.name = [studentDic objectForKey:@"name"];
        student.sex = [studentDic objectForKey:@"sex"];
        student.age = [studentDic objectForKey:@"age"];
    }
    
    NSLog(@"更新数据库id------>%@",studentDic);
    [[ModelDataManager sharedManager] saveContextUpdates];
}

/**
 *  根据id查询信息
 *
 *  @param ID id
 *
 *  @return 查询结果
 */
+(Student *)selectDataWithStudentID:(NSInteger)studentId
{
    NSManagedObjectContext *context = [[ModelDataManager sharedManager] managedObjectContext];
    //根据studentId 在 Student 表中查询出对应信息
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(studentId = %d)",studentId];
    [fetchRequest setPredicate:predicate];
    NSError *error;
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    //返回 Student 类型的数据
    return [fetchedObjects firstObject];
}

/**
 *  查询所有的信息
 *
 *  @return 所有信息数组
 */
+(NSArray *)selectAllData
{
    NSManagedObjectContext *context = [[ModelDataManager sharedManager] managedObjectContext];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    NSError *error;
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    
    return fetchedObjects;
}

/**
 *  删除指定id
 *
 *  @param id_ id_
 */
+ (void)deleteId:(NSString *)studentId
{
    NSManagedObjectContext *managedObjectContext = [[ModelDataManager sharedManager] managedObjectContext];
    //先根据id 查询出id 对应的对象 再将对象删除
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:managedObjectContext];
    //查询的条件
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"studentId = %@",studentId];
    request.predicate = predicate;
    NSError *error = nil;
    NSArray *objs = [managedObjectContext executeFetchRequest:request error:&error];
    //删除一条对象
    [managedObjectContext deleteObject:[objs firstObject]];
    [[ModelDataManager sharedManager] saveContextUpdates];
}

/**
 *  删除所有数据
 *
 */
+ (void)deleteAllData
{
    NSManagedObjectContext *managedObjectContext = [[ModelDataManager sharedManager] managedObjectContext];
    //查询出所有的对象，再将对象逐个删除
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    request.entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:managedObjectContext];
    
    NSError *error = nil;
    NSArray *objs = [managedObjectContext executeFetchRequest:request error:&error];
    
    //删除每一条数据
    for (NSManagedObject *obj in objs)
    {
        // 传入需要删除的实体对象
        [managedObjectContext deleteObject:obj];
        // 将结果同步到数据库
        //保存
        [[ModelDataManager sharedManager] saveContextUpdates];
    }
}

@end







